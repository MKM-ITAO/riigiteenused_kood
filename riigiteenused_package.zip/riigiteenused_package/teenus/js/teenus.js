(function($) {
  $('#edit-field-t-allasutuse-reference-tid').select2({
    placeholder: Drupal.t("Choose an institution")
  });
})(jQuery);
